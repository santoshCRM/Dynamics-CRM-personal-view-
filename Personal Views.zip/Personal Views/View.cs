﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personalview
{
    internal class View
    {
        
        private Guid _viewId;

        public Guid ViewId
        {
            get { return _viewId; }
            set { _viewId = value; }
        }
        private string _viewName;

        public string ViewName
        {
            get { return _viewName; }
            set { _viewName = value; }
        }
        private string _fetchXml;

        public string FetchXml
        {
            get { return _fetchXml; }
            set { _fetchXml = value; }
        }



    }
}
