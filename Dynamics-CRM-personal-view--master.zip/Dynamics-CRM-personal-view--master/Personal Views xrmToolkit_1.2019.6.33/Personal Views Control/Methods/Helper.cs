﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Description;
using System.IO;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.Text.RegularExpressions;
using Microsoft.Xrm.Sdk.Client;

namespace Personalview
{
    public static class Helper
    {

        private static Guid _viewID;

        public static Guid ViewID
        {
            get { return Helper._viewID; }
            set { Helper._viewID = value; }
        }
        private static List<systemUser> _systemUser;
        internal static List<systemUser> SystemUser
        {
            get { return Helper._systemUser; }
            set { Helper._systemUser = value; }
        }
        private static List<systemUser> _systemUsergrid;
        internal static List<systemUser> SystemUsergrid
        {
            get { return Helper._systemUsergrid; }
            set { Helper._systemUsergrid = value; }
        }
        private static List<Team> _teams;
        internal static List<Team> Teams
        {
            get { return Helper._teams; }
            set { Helper._teams = value; }
        }
        private static List<View> _views;

        internal static List<View> Views
        {
            get { return Helper._views; }
            set { Helper._views = value; }
        }
        private static List<Accessrights> _accessCollection;

        internal static List<Accessrights> AccessCollection
        {
            get { return Helper._accessCollection; }
            set { Helper._accessCollection = value; }
        }
        private static IOrganizationService _serviceProxy;
        public static IOrganizationService ServiceProxy
        {
            get { return Helper._serviceProxy; }
            set { Helper._serviceProxy = value; }
        }
        private static string _OrganizationUri;
        public static string OrganizationUri
        {
            get { return Helper._OrganizationUri; }
            set { Helper._OrganizationUri = value; }
        }
        private static ClientCredentials _Credentials = null;
        public static ClientCredentials Credentials
        {
            get { return Helper._Credentials; }
            set { Helper._Credentials = value; }
        }
        internal static void createConn(IOrganizationService Service)
        {

             _serviceProxy = Service;

        }
        internal static List<systemUser> getUsers()
        {

            SystemUser = new List<systemUser>();
            SystemUsergrid = new List<systemUser>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>  <entity name='systemuser'>    <attribute name='fullname' />    <attribute name='businessunitid' />    <attribute name='domainname' />    <attribute name='systemuserid' />    <order attribute='fullname' descending='false' />    <filter type='and'>      <condition attribute='isdisabled' operator='eq' value='0' />      <condition attribute='accessmode' operator='ne' value='3' />    </filter>  </entity></fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;

                foreach (Entity ent in returnCollection.Entities)
                {
                    systemUser user = new systemUser();
                    user.Domainname = ent.Attributes["domainname"].ToString();
                    user.FullName = ent.Attributes["fullname"].ToString();
                    user.BusinessUnit = ((EntityReference)ent.Attributes["businessunitid"]).Name;
                    user.SystemUserID = ent.Id;
                    SystemUser.Add(user);
                    SystemUsergrid.Add(user);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return SystemUser;
        }
        internal static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        internal static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        internal static List<Team> getTeambyBU(string buName)
        {
            List<Team> userTeams = new List<Team>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='team'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='teamid' />"
    + "<attribute name='teamtype' />"
     + "<filter>"
      + "<condition attribute='teamtype' operator='eq' value='0' />"
    + "</filter>"
    + "<order attribute='name' descending='false' />"
      + "<link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='ab'>"
      + "<filter type='and'>"
        + "<condition attribute='name' operator='eq' value='" + buName + "' />"
      + "</filter>"
    + "</link-entity>"
  + "</entity>"
+ "</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    Team team = new Team();
                    team.Name = ent.Attributes["name"].ToString();
                    team.BusinessUnit = (EntityReference)ent.Attributes["businessunitid"];
                    team.TeamId = ent.Id;
                    userTeams.Add(team);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return userTeams;
        }
        internal static List<systemUser> getUsersbyBU(string buName)
        {
            List<systemUser> users = new List<systemUser>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML =
               "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>"
  + "<entity name='systemuser'>"
    + "<attribute name='fullname' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='title' />"
    + "<attribute name='address1_telephone1' />"
    + "<attribute name='positionid' />"
    + "<attribute name='systemuserid' />"
    + "<order attribute='fullname' descending='false' />"
      + "<filter>"
      + "<condition attribute='isdisabled' operator='eq' value='0' />"
       + "<condition attribute='accessmode' operator='ne' value='3' />"
        + "<condition attribute='accessmode' operator='ne' value='5' />"
    + "</filter>"

    //+ "<link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='ab'>"
                //  + "<filter type='and'>"
                //    + "<condition attribute='name' operator='eq' value='"+buName+"' />"
                //  + "</filter>"
                //+ "</link-entity>"
  + "</entity>"
+ "</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    systemUser user = new systemUser();
                    user.FullName = ent.Attributes["fullname"].ToString();
                    user.SystemUserID = ent.Id;
                    users.Add(user);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return users;
        }
        internal static List<View> getViewbyUser(Guid systemUserId)
        {
            try
            {
                List<View> userViews = new List<View>();
                QueryExpression personalViews = new QueryExpression("userquery");
                personalViews.ColumnSet = new ColumnSet(true);
                personalViews.Criteria.Conditions.Add(new ConditionExpression("ownerid", ConditionOperator.Equal, systemUserId));

                EntityCollection viewCollection = _serviceProxy.RetrieveMultiple(personalViews);

                foreach (Entity personalView in viewCollection.Entities)
                {
                    View view = new View();
                    view.ViewId = personalView.Id;
                    view.FetchXml = personalView.Attributes["fetchxml"].ToString();
                    view.ViewName = personalView.Attributes["name"].ToString();
                    userViews.Add(view);
                }
                return userViews;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
                return null;
            }
        }
        internal static List<Accessrights> getSharedbyViewID(Guid ViewId)
        {
            try
            {
                List<Accessrights> accessColl = new List<Accessrights>();
                var accessRequest = new RetrieveSharedPrincipalsAndAccessRequest
                {
                    Target = new EntityReference("userquery", ViewId)
                };

                // The RetrieveSharedPrincipalsAndAccessResponse returns an entity reference
                // that has a LogicalName of "user" when returning access information for a
                // "team."
                var accessResponse = (RetrieveSharedPrincipalsAndAccessResponse)
                    _serviceProxy.Execute(accessRequest);
                foreach (var principalAccess in accessResponse.PrincipalAccesses)
                {
                    Accessrights access = new Accessrights();
                    access.Id = principalAccess.Principal.Id;
                    access.Type = principalAccess.Principal.LogicalName;
                    if (principalAccess.Principal.LogicalName == "team")
                    {
                        access.Name = getteambyId(principalAccess.Principal.Id);
                    }
                    else if (principalAccess.Principal.LogicalName == "systemuser")
                    {
                        access.Name = getuserbyId(principalAccess.Principal.Id);
                    }
                    string[] accessMask = principalAccess.AccessMask.ToString().Split(',');
                    foreach (string acc in accessMask)
                    {
                        if (Regex.Replace(acc, @"\s+", "") == "ReadAccess")
                            access.Read = true;
                        else if (Regex.Replace(acc, @"\s+", "") == "WriteAccess")
                            access.Write = true;
                        else if (Regex.Replace(acc, @"\s+", "") == "DeleteAccess")
                            access.Delete = true;
                        else if (Regex.Replace(acc, @"\s+", "") == "AssignAccess")
                            access.Assign = true;
                        else if (Regex.Replace(acc, @"\s+", "") == "ShareAccess")
                            access.Share = true;
                    }
                    access.IsSubmited = "Yes";
                    accessColl.Add(access);

                }
                return accessColl;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
                return null;
            }
        }

        internal static void ShareView(Guid viewId)
        {
            try
            {

                foreach (Accessrights Accrights in AccessCollection)
                {
                    if (Accrights.Type == "team")
                    {
                        if (Accrights.Read == false && Accrights.Write == false && Accrights.Assign == false && Accrights.Delete == false && Accrights.Share == false)
                        {
                            if (Accrights.IsSubmited == "Yes")
                            {
                                var Revokerequest = new RevokeAccessRequest
                                {
                                    Revokee = new EntityReference("team", Accrights.Id),
                                    Target = new EntityReference("userquery", viewId)
                                };
                                _serviceProxy.Execute(Revokerequest);
                            }
                        }
                        else
                        {
                            var Grantrequest = new GrantAccessRequest
                            {
                                PrincipalAccess = new PrincipalAccess
                                {
                                    AccessMask = getAccessMode(Accrights),
                                    Principal = new EntityReference("team", Accrights.Id)
                                },
                                Target = new EntityReference("userquery", viewId)
                            };

                            _serviceProxy.Execute(Grantrequest);
                        }
                    }

                    else if (Accrights.Type == "systemuser")
                    {

                        if (Accrights.Read == false && Accrights.Write == false && Accrights.Assign == false && Accrights.Delete == false && Accrights.Share == false)
                        {
                            if (Accrights.IsSubmited == "Yes")
                            {
                                var Revokerequest = new RevokeAccessRequest
                                {
                                    Revokee = new EntityReference("systemuser", Accrights.Id),
                                    Target = new EntityReference("userquery", viewId)
                                };
                                _serviceProxy.Execute(Revokerequest);
                            }
                        }
                        else
                        {
                            var Grantrequest = new GrantAccessRequest
                            {
                                PrincipalAccess = new PrincipalAccess
                                {
                                    AccessMask = getAccessMode(Accrights),
                                    Principal = new EntityReference("systemuser", Accrights.Id)
                                },
                                Target = new EntityReference("userquery", viewId)
                            };

                            _serviceProxy.Execute(Grantrequest);
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message.ToString());

            }
        }

        internal static string getuserbyId(Guid systemUserId)
        {
            try
            {
                Entity user = _serviceProxy.Retrieve("systemuser", systemUserId, new ColumnSet(true));
                return user.Attributes["fullname"].ToString();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
                return string.Empty;
            }
        }
        internal static string getteambyId(Guid teamId)
        {
            try
            {
                Entity user = _serviceProxy.Retrieve("team", teamId, new ColumnSet(true));
                return user.Attributes["name"].ToString();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
                return string.Empty;
            }
        }
        internal static AccessRights getAccessMode(Accessrights Accrights)
        {
            AccessRights sdColl = new AccessRights();
            if (Accrights.Assign)
                sdColl = AccessRights.AssignAccess;
            if (Accrights.Delete)
                sdColl = AccessRights.DeleteAccess;
            if (Accrights.Read)
                sdColl = AccessRights.ReadAccess;
            if (Accrights.Share)
                sdColl = AccessRights.ShareAccess;
            if (Accrights.Write)
                sdColl = AccessRights.WriteAccess;

            if (Accrights.Assign && Accrights.Delete)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess;
            if (Accrights.Assign && Accrights.Read)
                sdColl = AccessRights.AssignAccess | AccessRights.ReadAccess;
            if (Accrights.Assign && Accrights.Share)
                sdColl = AccessRights.AssignAccess | AccessRights.ShareAccess;
            if (Accrights.Assign && Accrights.Write)
                sdColl = AccessRights.AssignAccess | AccessRights.WriteAccess;
            if (Accrights.Delete && Accrights.Read)
                sdColl = AccessRights.DeleteAccess | AccessRights.ReadAccess;
            if (Accrights.Delete && Accrights.Share)
                sdColl = AccessRights.DeleteAccess | AccessRights.ShareAccess;
            if (Accrights.Delete && Accrights.Write)
                sdColl = AccessRights.DeleteAccess | AccessRights.WriteAccess;
            if (Accrights.Read && Accrights.Share)
                sdColl = AccessRights.ReadAccess | AccessRights.ShareAccess;
            if (Accrights.Read && Accrights.Write)
                sdColl = AccessRights.ReadAccess | AccessRights.WriteAccess;
            if (Accrights.Share && Accrights.Write)
                sdColl = AccessRights.ShareAccess | AccessRights.WriteAccess;

            if (Accrights.Assign && Accrights.Delete && Accrights.Read)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess | AccessRights.ReadAccess;
            if (Accrights.Assign && Accrights.Delete && Accrights.Share)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess | AccessRights.ShareAccess;
            if (Accrights.Assign && Accrights.Delete && Accrights.Write)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess | AccessRights.WriteAccess;
            if (Accrights.Assign && Accrights.Read && Accrights.Share)
                sdColl = AccessRights.AssignAccess | AccessRights.ReadAccess | AccessRights.ShareAccess;
            if (Accrights.Assign && Accrights.Read && Accrights.Write)
                sdColl = AccessRights.AssignAccess | AccessRights.ReadAccess | AccessRights.WriteAccess;
            if (Accrights.Assign && Accrights.Share && Accrights.Write)
                sdColl = AccessRights.AssignAccess | AccessRights.ShareAccess | AccessRights.WriteAccess;
            if (Accrights.Delete && Accrights.Read && Accrights.Share)
                sdColl = AccessRights.DeleteAccess | AccessRights.ReadAccess | AccessRights.ShareAccess;
            if (Accrights.Delete && Accrights.Read && Accrights.Write)
                sdColl = AccessRights.DeleteAccess | AccessRights.ReadAccess | AccessRights.WriteAccess;
            if (Accrights.Delete && Accrights.Share && Accrights.Write)
                sdColl = AccessRights.DeleteAccess | AccessRights.ShareAccess | AccessRights.WriteAccess;
            if (Accrights.Read && Accrights.Share && Accrights.Write)
                sdColl = AccessRights.ReadAccess | AccessRights.ShareAccess | AccessRights.WriteAccess;

            if (Accrights.Assign && Accrights.Delete && Accrights.Read && Accrights.Share)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess | AccessRights.ReadAccess | AccessRights.ShareAccess;
            if (Accrights.Assign && Accrights.Delete && Accrights.Read && Accrights.Write)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess | AccessRights.ReadAccess | AccessRights.WriteAccess;
            if (Accrights.Delete && Accrights.Read && Accrights.Share && Accrights.Write)
                sdColl = AccessRights.DeleteAccess | AccessRights.ReadAccess | AccessRights.ShareAccess | AccessRights.WriteAccess;

            if (Accrights.Assign && Accrights.Delete && Accrights.Read && Accrights.Share && Accrights.Write)
                sdColl = AccessRights.AssignAccess | AccessRights.DeleteAccess | AccessRights.ReadAccess | AccessRights.ShareAccess | AccessRights.WriteAccess;

            return sdColl;

        }
    }
}
