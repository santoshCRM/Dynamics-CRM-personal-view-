﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using XrmToolBox.Extensibility;
namespace Personalview
{
    public partial class PersonalView :  PluginControlBase//UserControl
    {
        public PersonalView()
        {
            InitializeComponent();
           
        }
        void GetUsers()
        {
            Helper.createConn(Service);
            
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Retrieving users...",
                Work = (bw, m) =>
                {

                    if (base.Service != null)
                    {
                       // Helper.createConn(((Microsoft.Xrm.Tooling.Connector.CrmServiceClient)base.Service).OrganizationServiceProxy);
                        drp_users.DataSource = null;
                        if (grdview_Pview.InvokeRequired)
                        {
                            grdview_Pview.Invoke(new Action(() =>
                            {
                                grdview_Pview.DataSource = null;
                            }));
                        }
                        else
                            grdview_Pview.DataSource = null;
                        if(Helper.AccessCollection!=null)
                        Helper.AccessCollection.Clear();
                        lstview_team.DataSource = null;
                        lstview_users.DataSource = null;
                        grdview_access.DataSource = null;

                        drp_users.Items.Clear();
                        List<systemUser> systemUsers = Helper.getUsers();
                        systemUsers.Sort((p, q) => p.FullName.CompareTo(q.FullName));
                        systemUser Select = new systemUser();
                        Select.FullName = "--Select--";
                        Select.SystemUserID = Guid.Empty;
                        systemUsers.Insert(0, Select);
                        drp_users.DataSource = systemUsers;
                        drp_users.DisplayMember = "FullName";
                        drp_users.ValueMember = "SystemUserID";
                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {

                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });
        }
        void RunShare()
        {
            try
            {

                WorkAsync(new WorkAsyncInfo
                {
                    Message = "Executing request...",
                    Work = (bw, m) =>
                    {
                        if (Helper.ViewID != Guid.Empty)
                        {
                            Helper.ShareView(Helper.ViewID);
                            grdview_access.DataSource = null;
                        }

                    },
                    PostWorkCallBack = m =>
                    {
                        if (m.Error == null)
                        {
                            MessageBox.Show("Shareing completed");
                            if(Helper.AccessCollection!=null)
                            Helper.AccessCollection.Clear();
                        }
                        else
                        {
                            MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                        }
                    }
                });


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
            private void btn_close_Click(object sender, EventArgs e)
        {
            base.CloseTool();
        }

        private void btn_rtv_Click(object sender, EventArgs e)
        {
            ExecuteMethod(GetUsers);

        }

        private void btn_run_Click(object sender, EventArgs e)
        {
            ExecuteMethod(RunShare);

          
        }

        private void drp_users_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.drp_users.SelectedIndex > 0;
            if (flag)
            {
                systemUser user = (systemUser)drp_users.SelectedItem;
                ConnectionDetail.Impersonate(user.SystemUserID);
                List<View> userViews =   Helper.getViewbyUser(user.SystemUserID);
                ConnectionDetail.RemoveImpersonation();
                userViews.Sort((p, q) => p.ViewName.CompareTo(q.ViewName));
                Helper.Views = userViews;
                if (grdview_Pview.InvokeRequired)
                {
                    grdview_Pview.Invoke(new Action(() =>
                    {
                        grdview_Pview.DataSource = Helper.Views;
                    }));
                }
                else
                    grdview_Pview.DataSource = Helper.Views;

                grdview_Pview.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_Pview.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_Pview.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                Helper.AccessCollection.Clear();
                lstview_team.DataSource = null;
                lstview_users.DataSource = null;
                grdview_access.DataSource = null;
                lbl_bu.Text = user.BusinessUnit;
            }
        }

        private void grdview_Pview_MouseDoubleClick(object sender, MouseEventArgs e)
        {
           // WorkAsync(new WorkAsyncInfo
           //{
           //    Message = "Executing request...",
           //    Work = (bw, m) =>
           //    {
                   bool flag = this.drp_users.SelectedIndex > 0;

                   if (flag)
                   {
                       grdview_access.DataSource = null;
                       lstview_team.DataSource = null;
                       lstview_users.DataSource = null;
                       Helper.AccessCollection = null;
                       systemUser user = (systemUser)drp_users.SelectedItem;
                       foreach (DataGridViewRow dr in this.grdview_Pview.SelectedRows)
                       {
                           #region Add access grid
                           Helper.ViewID = new Guid(dr.Cells[0].Value.ToString());
                           List<Accessrights> access = Helper.getSharedbyViewID(new Guid(dr.Cells[0].Value.ToString()));
                           if (access.Count() > 0)
                           {
                               Helper.AccessCollection = access;
                               grdview_access.DataSource = Helper.AccessCollection;
                           }
                           #endregion

                           #region Add Team grid
                           List<Team> team = Helper.getTeambyBU(user.BusinessUnit);
                           Helper.Teams = team;
                           lstview_team.DataSource = Helper.Teams;
                           lstview_team.DisplayMember = "Name";
                           lstview_team.ValueMember = "TeamId";
                           #endregion
                           #region Add user grid
                           List<systemUser> users = Helper.getUsersbyBU(user.BusinessUnit);
                           Helper.SystemUsergrid = users;
                           lstview_users.DataSource = Helper.SystemUsergrid;
                           lstview_users.DisplayMember = "FullName";
                           lstview_users.ValueMember = "SystemUserID";
                           #endregion
                           break;
                       }
                   }
           //    },
           //    PostWorkCallBack = m =>
           //    {
           //        if (m.Error == null)
           //        {

           //        }
           //        else
           //        {
           //            MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
           //                            MessageBoxIcon.Error);
           //        }
           //    }
           //});
        }

        private void lstview_team_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (Helper.AccessCollection != null)
            {
                Guid teamid = ((Personalview.Team)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).TeamId;
                var result = Helper.AccessCollection.Where(x => x.Id.Equals(teamid));
                if (result.Count() < 1)
                {
                    Accessrights accessright = new Accessrights();
                    accessright.Id = ((Personalview.Team)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).TeamId;
                    accessright.Name = ((Personalview.Team)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).Name;
                    accessright.Type = "team";
                    accessright.Read = false;
                    accessright.Write = false;
                    accessright.Share = false;
                    accessright.Delete = false;
                    accessright.Assign = false;
                    accessright.IsSubmited = "No";
                    Helper.AccessCollection.Add(accessright);
                    grdview_access.DataSource = null;
                    grdview_access.DataSource = Helper.AccessCollection;
                }
                else
                    MessageBox.Show("Team allready exist");
            }
            else
            {
                List<Accessrights> AccColl = new List<Accessrights>();
                Accessrights accessright = new Accessrights();
                accessright.Id = ((Personalview.Team)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).TeamId;
                accessright.Name = ((Personalview.Team)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).Name;
                accessright.Type = "team";
                accessright.Read = false;
                accessright.Write = false;
                accessright.Share = false;
                accessright.Delete = false;
                accessright.Assign = false;
                accessright.IsSubmited = "No";
                AccColl.Add(accessright);
                Helper.AccessCollection = AccColl;
                grdview_access.DataSource = null;
                grdview_access.DataSource = Helper.AccessCollection;

            }
         
        }

        private void lstview_users_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(Helper.AccessCollection!=null)
            {
                Guid systemUserid = ((Personalview.systemUser)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).SystemUserID;
                var result = Helper.AccessCollection.Where(x => x.Id.Equals(systemUserid));
                if (result.Count() < 1)
                {
                    Accessrights accessright = new Accessrights();
                    accessright.Id = ((Personalview.systemUser)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).SystemUserID;
                    accessright.Name = ((Personalview.systemUser)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).FullName;
                    accessright.Type = "systemuser";
                    accessright.Read = false;
                    accessright.Write = false;
                    accessright.Share = false;
                    accessright.Delete = false;
                    accessright.Assign = false;
                    accessright.IsSubmited = "No";
                    Helper.AccessCollection.Add(accessright);
                    grdview_access.DataSource = null;
                    grdview_access.DataSource = Helper.AccessCollection;
                }
                else
                    MessageBox.Show("User allready exist");
            }
            else
            {
                List<Accessrights> AccColl = new List<Accessrights>();
                Accessrights accessright = new Accessrights();
                accessright.Id = ((Personalview.systemUser)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).SystemUserID;
                accessright.Name = ((Personalview.systemUser)(((System.Windows.Forms.ListBox)(sender)).SelectedItem)).FullName;
                accessright.Type = "systemuser";
                accessright.Read = false;
                accessright.Write = false;
                accessright.Share = false;
                accessright.Delete = false;
                accessright.Assign = false;
                accessright.IsSubmited = "No";
                AccColl.Add(accessright);
                Helper.AccessCollection = AccColl;
                grdview_access.DataSource = null;
                grdview_access.DataSource = Helper.AccessCollection;

            }
           
        }

        private void grdview_access_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (((System.Windows.Forms.DataGridView)(sender)).CurrentCell.ValueType.FullName == "System.Boolean")
                {
                    if ((bool)(((System.Windows.Forms.DataGridView)(sender)).CurrentCell).Value)
                        (((System.Windows.Forms.DataGridView)(sender)).CurrentCell).Value = false;
                    else
                        (((System.Windows.Forms.DataGridView)(sender)).CurrentCell).Value = true;

                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }
    }
}
