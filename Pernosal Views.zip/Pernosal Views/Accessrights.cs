﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personalview
{
    internal class Accessrights
    {
        private Guid _Id;

        public Guid Id
        {
            get { return _Id; }
            set { _Id = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _Type;

        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        private bool _Read;

        public bool Read
        {
            get { return _Read; }
            set { _Read = value; }
        }
        private bool _Write;

        public bool Write
        {
            get { return _Write; }
            set { _Write = value; }
        }
        private bool _Delete;

        public bool Delete
        {
            get { return _Delete; }
            set { _Delete = value; }
        }
        private bool _Assign;

        public bool Assign
        {
            get { return _Assign; }
            set { _Assign = value; }
        }
        private bool _Share;

        public bool Share
        {
            get { return _Share; }
            set { _Share = value; }
        }
        private string _isSubmited;

        public string IsSubmited
        {
            get { return _isSubmited; }
            set { _isSubmited = value; }
        }
    }
}
