﻿///script/fetchutil.js
var dataToreturn = [];
var _sOrgName = "";
function getData() {
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
    "<entity name='activitypointer'>" +
      "<attribute name='subject' />" +
      "<attribute name='ownerid' />" +
      "<attribute name='activitytypecode' />" +
      "<attribute name='statecode' />" +
      "<attribute name='scheduledend' />" +
      "<attribute name='activityid' />" +
      "<attribute name='statuscode' />" +
      "<filter type='and'>" +
        "<condition attribute='isregularactivity' operator='eq' value='1' />" +
        "<condition attribute='statecode' operator='in'>" +
          "<value>0</value>" +
          "<value>3</value>" +
        "</condition>" +
        "<condition attribute='scheduledend' operator='not-null' />" +
           "<condition attribute='activitytypecode' operator='in'>" +
    "<value>4201</value>" +
    "<value>4202</value>" +
    "<value>4204</value>" +
    "<value>4207</value>" +
    "<value>4210</value>" +
    "<value>4214</value>" +
    "<value>4212</value>" +
    "<value>4251</value>" +
    "<value>10006</value>" +
    "</condition>" +
     "<condition attribute='ownerid' operator='eq-userid' />" +
      "</filter>" +
    "</entity>" +
  "</fetch>";
    retrieveDatabyFetch(fetchXml);
    return dataToreturn;
}

function retrieveDatabyFetch(fetchXml) {
     debugger;
    var serverUrl = window.parent.Xrm.Page.context.getClientUrl();
    _oService = new FetchUtil(_sOrgName, serverUrl);
    var results = _oService.Fetch(fetchXml);
    if (results.length > 0) {
        readRecordsOnSuccess(results);
    }
}
function readRecordsOnSuccess(data) {
    // Loop through the retrieved records
    for (var indx = 0; indx < data.length; indx++) {
        switch (data[indx].attributes.activitytypecode.value) {
            case 'phonecall':
                {
                    dataToreturn.push(
                                        {
                                            title: data[indx].attributes.subject.value,
                                        start: data[indx].attributes.scheduledend.formattedValue,
                                        color: '#257e4a',
                                        url: window.parent.Xrm.Page.context.getClientUrl() +
        "/main.aspx?etc=4210&id=%7b" + data[indx].attributes.activityid.value + "%7d&newWindow=true&pagetype=entityrecord"
                                        }
                                    );
                }
                break;
            case 'task':
                {
                    dataToreturn.push(
                                        {
                                            title: data[indx].attributes.subject.value,
                                            start: data[indx].attributes.scheduledend.formattedValue,
                                            url: window.parent.Xrm.Page.context.getClientUrl() +
       "/main.aspx?etc=4212&id=%7b" + data[indx].attributes.activityid.value + "%7d&newWindow=true&pagetype=entityrecord"
                                        }
                                    ); 
                    break;
                }
            case 'appointment':
                {
                    dataToreturn.push(
                                        {
                                            title: data[indx].attributes.subject.value,
                                            start: data[indx].attributes.scheduledend.formattedValue,
                                            url: window.parent.Xrm.Page.context.getClientUrl() +
       "/main.aspx?etc=4201&id=%7b" + data[indx].attributes.activityid.value + "%7d&newWindow=true&pagetype=entityrecord"
                                        }
                                    );
                    break;
                }
        }

    }
    
}

//Sample data
//return   [
//                   {

//                   },
//                   {
//                       title: 'Long Event',
//                       start: '2017-05-07',
//                       end: '2017-05-10'
//                   },
//                   {
//                       id: 999,
//                       title: 'Repeating Event',
//                       start: '2017-05-09T16:00:00'
//                   },
//                   {
//                       id: 999,
//                       title: 'Repeating Event',
//                       start: '2017-05-16T16:00:00'
//                   },
//                   {
//                       title: 'Conference',
//                       start: '2017-05-11',
//                       end: '2017-05-13'
//                   },
//                   {
//                       title: 'Meeting',
//                       start: '2017-05-12T10:30:00',
//                       end: '2017-05-12T12:30:00'
//                   },
//                   {
//                       title: 'Lunch',
//                       start: '2017-05-12T12:00:00'
//                   },
//                   {
//                       title: 'Meeting',
//                       start: '2017-05-12T14:30:00'
//                   },
//                   {
//                       title: 'Happy Hour',
//                       start: '2017-05-12T17:30:00'
//                   },
//                   {
//                       title: 'Dinner',
//                       start: '2017-05-12T20:00:00'
//                   },
//                   {
//                       title: 'Birthday Party',
//                       start: '2017-05-13T07:00:00'
//                   },
//                   {
//                       title: 'Click for Google',
//                       url: 'http://google.com/',
//                       start: '2017-05-28'
//                   }
// ]